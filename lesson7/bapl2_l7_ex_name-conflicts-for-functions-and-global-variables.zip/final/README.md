# Final Project

Final project for Building A Programming Language.

Run test

```
lua test.lua
```

